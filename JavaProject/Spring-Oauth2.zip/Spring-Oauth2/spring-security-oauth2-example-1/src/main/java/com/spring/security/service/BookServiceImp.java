package com.spring.security.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.security.model.Book;
import com.spring.security.repository.BookRepository;
import com.spring.security.request.BookRequest;

@Service
@Transactional(readOnly = true)
public class BookServiceImp implements BookService {

	@Autowired
	private BookRepository bookRepository;

	@Transactional
	public long save(BookRequest bookRequest) {
		Book book = new Book();
		book.setTitle(bookRequest.getTitle());
		book.setYear(bookRequest.getYear());
		book.setIsbn(bookRequest.getIsbn());
		book.setAvailable(bookRequest.getAvailable());
		Book savedBook = bookRepository.save(book);
		return savedBook.getId();
	}

	@Transactional
	public void update(BookRequest bookRequest) {
		Book book = this.getBook(bookRequest.getId());
		book.setTitle(bookRequest.getTitle());
		book.setYear(bookRequest.getYear());
		book.setIsbn(bookRequest.getIsbn());
		book.setAvailable(bookRequest.getAvailable());
		bookRepository.save(book);
	}

	public Book getBook(Long id) {
		Book book = bookRepository.findOne(id);
		return book;
	}

	public List<Book> list() {
		return bookRepository.findAll();
	}

	@Transactional
	public void delete(BookRequest bookRequest) {
		bookRepository.delete(bookRequest.getId());
	}

}

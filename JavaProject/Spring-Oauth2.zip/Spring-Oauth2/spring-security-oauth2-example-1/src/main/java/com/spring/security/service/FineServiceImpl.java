package com.spring.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.security.repository.FineRepository;

@Service
public class FineServiceImpl implements FineService {

	@Autowired
	FineRepository fineRepository;
	

}

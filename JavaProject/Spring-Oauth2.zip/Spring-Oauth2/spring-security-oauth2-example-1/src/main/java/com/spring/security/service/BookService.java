package com.spring.security.service;

import java.util.List;

import com.spring.security.model.Book;
import com.spring.security.request.BookRequest;

public interface BookService {

	long save(BookRequest bookRequest);

	void update(BookRequest bookRequest);

	Book getBook(Long id);

	List<Book> list();

	void delete(BookRequest bookRequest);

}

package com.spring.security.contoller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.security.request.UserRequest;
import com.spring.security.service.UserService;

@RestController
@RequestMapping("newusers")
public class NewUserController {

	@Autowired
	UserService userService;

	@PostMapping
	public ResponseEntity saveUser(@Valid @RequestBody UserRequest userRequest) {
		try {
			userService.save(userRequest);
			return new ResponseEntity<>("User has been created", HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping
	public ResponseEntity updateUser(@Valid @RequestBody UserRequest userRequest) {
		try {
			userService.update(userRequest);
			return new ResponseEntity<>("User has been updated", HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping
	public ResponseEntity deleteUser(@Valid @RequestBody UserRequest userRequest) {
		try {
			userService.delete(userRequest);
			return new ResponseEntity<>("User has been deleted", HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}

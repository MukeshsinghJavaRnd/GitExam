package com.spring.security.service;

import java.util.List;

import com.spring.security.model.Author;


public interface AuthorService {

	List<Author> list();

}

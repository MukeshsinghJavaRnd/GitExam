package com.spring.security.service;

public interface FineService {

}

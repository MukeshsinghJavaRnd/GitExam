package com.spring.security.service;

import com.spring.security.request.IssueRequest;

public interface IssueService {
	
	public void issueBook(IssueRequest issueRequest);
	
	public void returnBook(IssueRequest issueRequest);
	
	public void renewBook(IssueRequest issueRequest);

}

package com.spring.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.security.model.Fine;

public interface FineRepository extends JpaRepository<Fine, Long> {

}

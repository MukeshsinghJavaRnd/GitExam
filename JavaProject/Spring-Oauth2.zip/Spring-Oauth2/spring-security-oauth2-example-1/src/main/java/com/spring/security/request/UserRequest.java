package com.spring.security.request;

import javax.validation.constraints.NotNull;

public class UserRequest {

	private Long id;

	@NotNull
	private String name;

	@NotNull
	private String email;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}

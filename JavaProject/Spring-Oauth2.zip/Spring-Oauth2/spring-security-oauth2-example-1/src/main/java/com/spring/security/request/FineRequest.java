package com.spring.security.request;

public class FineRequest {

}

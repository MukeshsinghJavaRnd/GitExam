package com.spring.security.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.security.model.User;
import com.spring.security.repository.UserRepository;
import com.spring.security.request.UserRequest;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userDao;

	@Override
	@Transactional
	public void save(UserRequest userRequest) {
		User user = new User();
		user.setEmail(userRequest.getEmail());
		user.setName(userRequest.getName());
		userDao.save(user);
	}

	@Override
	@Transactional
	public void update(UserRequest userRequest) {
		User user = new User();
		user.setId(userRequest.getId());
		user.setEmail(userRequest.getEmail());
		user.setName(userRequest.getName());
		userDao.save(user);
	}

	@Override
	@Transactional
	public void delete(UserRequest userRequest) {
		User user = new User();
		user.setId(userRequest.getId());
		user.setEmail(userRequest.getEmail());
		user.setName(userRequest.getName());
		userDao.delete(userRequest.getId());
	}

	@Override
	public User getUser(Long id) {
		return userDao.findOne(id);

	}

	@Override
	public List<User> list() {
		return userDao.findAll();
	}

}

package com.spring.security.service;

import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.security.model.Fine;
import com.spring.security.model.Issue;
import com.spring.security.repository.FineRepository;
import com.spring.security.repository.IssueRepository;
import com.spring.security.request.IssueRequest;
import com.spring.security.utils.ApplicationConstants;


@Service
public class IssueServiceImpl implements IssueService {

	@Autowired
	IssueRepository issueRepository;

	@Autowired
	FineRepository fineRepository;

	@Override
	public void issueBook(IssueRequest issueRequest) {
		Issue issue = new Issue();
		issue.setUserId(issueRequest.getUserId());
		issue.setBookId(issueRequest.getBookId());
		issue.setIssueStartDate(LocalDateTime.now());
		issue.setIssueEndDate(LocalDateTime.now().plusDays(7));
		issue.setIssueType(ApplicationConstants.ISSUE_TYPE_ISSUE);
		issueRepository.save(issue);
	}

	@Override
	public void returnBook(IssueRequest issueRequest) {
		Issue alreadyIssuedDetails = issueRepository.findOne(issueRequest.getId());
		if (alreadyIssuedDetails != null) {

			if (alreadyIssuedDetails.getIssueEndDate().isBefore(LocalDateTime.now())) {
				// fine
				Fine fine = new Fine();
				fine.setAmount(100d);
				fine.setPaymentDate(new Date());
				fineRepository.save(fine);
			}
			Issue issue = new Issue();
			issue.setId(alreadyIssuedDetails.getId());
			issue.setUserId(issueRequest.getUserId());
			issue.setBookId(issueRequest.getBookId());
			issue.setIssueStartDate(LocalDateTime.now());
			issue.setIssueEndDate(LocalDateTime.now());
			issue.setIssueType(ApplicationConstants.ISSUE_TYPE_RETURN);
			issue.setCreateDate(alreadyIssuedDetails.getCreateDate());
			issueRepository.save(issue);

		} else {

		}
	}

	@Override
	public void renewBook(IssueRequest issueRequest) {
		Issue alreadyIssuedDetails = issueRepository.findOne(issueRequest.getId());
		if (alreadyIssuedDetails != null) {

			if (alreadyIssuedDetails.getIssueEndDate().isBefore(LocalDateTime.now())) {
				// fine
				Fine fine = new Fine();
				fine.setAmount(100d);
				fine.setPaymentDate(new Date());
				fineRepository.save(fine);
			}
			Issue issue = new Issue();
			issue.setId(alreadyIssuedDetails.getId());
			issue.setUserId(issueRequest.getUserId());
			issue.setBookId(issueRequest.getBookId());
			issue.setIssueStartDate(LocalDateTime.now());
			issue.setIssueEndDate(alreadyIssuedDetails.getIssueEndDate().plusDays(7));
			issue.setIssueType(ApplicationConstants.ISSUE_TYPE_RENEW);
			issue.setCreateDate(alreadyIssuedDetails.getCreateDate());
			issueRepository.save(issue);
		} else {

		}

	}
}

package com.spring.security.service;

import java.util.List;

import com.spring.security.model.User;
import com.spring.security.request.UserRequest;


public interface UserService {

	public void save(UserRequest userRequest);

	public void update(UserRequest userRequest);

	public void delete(UserRequest userRequest);

	public User getUser(Long id);

	public List<User> list();

}

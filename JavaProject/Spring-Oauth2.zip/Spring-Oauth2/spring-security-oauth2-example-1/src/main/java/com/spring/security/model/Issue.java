package com.spring.security.model;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "issue")
public class Issue {

	@Id
	@GeneratedValue
	@Column(name = "ID")
	private Long id;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "book_id")
	private Long bookId;

	@Column(name = "issue_start_date")
	private LocalDateTime issueStartDate;

	private LocalDateTime issueEndDate;

	@Column(name = "issue_type")
	private Integer issueType;

	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_date")
	private Date createDate;

	@UpdateTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modify_date")
	private Date modifyDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getBookId() {
		return bookId;
	}

	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

	public LocalDateTime getIssueStartDate() {
		return issueStartDate;
	}

	public void setIssueStartDate(LocalDateTime issueStartDate) {
		this.issueStartDate = issueStartDate;
	}

	public LocalDateTime getIssueEndDate() {
		return issueEndDate;
	}

	public void setIssueEndDate(LocalDateTime issueEndDate) {
		this.issueEndDate = issueEndDate;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public Integer getIssueType() {
		return issueType;
	}

	public void setIssueType(Integer issueType) {
		this.issueType = issueType;
	}

}

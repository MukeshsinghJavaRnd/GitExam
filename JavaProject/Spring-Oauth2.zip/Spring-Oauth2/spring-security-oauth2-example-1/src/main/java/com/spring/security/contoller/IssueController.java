package com.spring.security.contoller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.security.request.IssueRequest;
import com.spring.security.service.IssueService;


@RestController
@RequestMapping("issue")
public class IssueController {

	@Autowired
	IssueService issueService;

	// 1. issue book
	@PostMapping
	public ResponseEntity<Void> issueBook(@Valid @RequestBody IssueRequest issueRequest) {
		try {
			issueService.issueBook(issueRequest);
			return new ResponseEntity("Book has been issued", HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// 2. return book
	@PutMapping("return")
	public ResponseEntity<Void> returnBook(@Valid @RequestBody IssueRequest issueRequest) {
		try {
			issueService.returnBook(issueRequest);
			return new ResponseEntity("Book has been returned", HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// 3. renew book
	@PutMapping("renew")
	public ResponseEntity<Void> renewBook(@Valid @RequestBody IssueRequest issueRequest) {
		try {
			issueService.renewBook(issueRequest);
			return new ResponseEntity("Book has been renewd", HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}

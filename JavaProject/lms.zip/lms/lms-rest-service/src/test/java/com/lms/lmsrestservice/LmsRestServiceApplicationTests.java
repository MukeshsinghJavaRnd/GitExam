package com.lms.lmsrestservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LmsRestServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

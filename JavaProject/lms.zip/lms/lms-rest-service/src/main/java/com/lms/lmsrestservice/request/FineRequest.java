package com.lms.lmsrestservice.request;

public class FineRequest {

}

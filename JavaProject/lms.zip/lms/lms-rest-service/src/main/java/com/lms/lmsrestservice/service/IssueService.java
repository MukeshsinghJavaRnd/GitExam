package com.lms.lmsrestservice.service;

import com.lms.lmsrestservice.model.Issue;
import com.lms.lmsrestservice.request.IssueRequest;

public interface IssueService {
	
	public Issue issueBook(IssueRequest issueRequest);
	
	public Issue returnBook(IssueRequest issueRequest);
	
	public Issue renewBook(IssueRequest issueRequest);

}

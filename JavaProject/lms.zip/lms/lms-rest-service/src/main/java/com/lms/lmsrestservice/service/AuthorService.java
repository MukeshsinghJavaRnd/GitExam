package com.lms.lmsrestservice.service;

import java.util.List;

import com.lms.lmsrestservice.model.Author;

public interface AuthorService {
	
	List<Author> list();

}

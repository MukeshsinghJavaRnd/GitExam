package com.lms.lmsrestservice.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.lmsrestservice.exception.InternalServerError;
import com.lms.lmsrestservice.request.FineRequest;
import com.lms.lmsrestservice.service.FineService;

@RestController
@RequestMapping("fine")
public class FineController {
	
	@Autowired
	FineService fineService;
	
	//1. add fine
	
	@PostMapping
	public ResponseEntity<Void> saveBook(@Valid @RequestBody FineRequest fineRequest) {
		try {
			//bookService.save(bookRequest);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} catch (Exception e) {
			throw new InternalServerError();
		}
	} 
	
	// 2. adjust fine
	
	// 3. get fine for user

}

package com.lms.lmsrestservice.service;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.lmsrestservice.exception.ResourceNotFound;
import com.lms.lmsrestservice.model.Fine;
import com.lms.lmsrestservice.model.Issue;
import com.lms.lmsrestservice.repository.FineRepository;
import com.lms.lmsrestservice.repository.IssueRepository;
import com.lms.lmsrestservice.request.IssueRequest;
import com.lms.lmsrestservice.utils.ApplicationConstants;

@Service
public class IssueServiceImpl implements IssueService {

	@Autowired
	IssueRepository issueRepository;

	@Autowired
	FineRepository fineRepository;

	@Override
	public Issue issueBook(IssueRequest issueRequest) {
		Issue issue = new Issue();
		issue.setUserId(issueRequest.getUserId());
		issue.setBookId(issueRequest.getBookId());
		issue.setIssueStartDate(LocalDateTime.now());
		issue.setIssueEndDate(LocalDateTime.now().plusDays(7));
		issue.setIssueType(ApplicationConstants.ISSUE_TYPE_ISSUE);

		return issueRepository.save(issue);
	}

	@Override
	public Issue returnBook(IssueRequest issueRequest) {
		Optional<Issue> optionalIssue = issueRepository.findById(issueRequest.getId());
		if (optionalIssue.isPresent()) {
			Issue alreadyIssuedDetails = optionalIssue.get();

			if (alreadyIssuedDetails.getIssueEndDate().isBefore(LocalDateTime.now())) {
				// fine
				Fine fine = new Fine();
				fine.setAmount(100d);
				fine.setPaymentDate(new Date());
				fineRepository.save(fine);
			}
			Issue issue = new Issue();
			issue.setId(alreadyIssuedDetails.getId());
			issue.setUserId(issueRequest.getUserId());
			issue.setBookId(issueRequest.getBookId());
			issue.setIssueStartDate(LocalDateTime.now());
			issue.setIssueEndDate(LocalDateTime.now());
			issue.setIssueType(ApplicationConstants.ISSUE_TYPE_RETURN);
			issue.setCreateDate(alreadyIssuedDetails.getCreateDate());
			return issueRepository.save(issue);

		} else {
			throw new ResourceNotFound();
		}
	}

	@Override
	public Issue renewBook(IssueRequest issueRequest) {
		Optional<Issue> optionalIssue = issueRepository.findById(issueRequest.getId());
		if (optionalIssue.isPresent()) {
			Issue alreadyIssuedDetails = optionalIssue.get();

			if (alreadyIssuedDetails.getIssueEndDate().isBefore(LocalDateTime.now())) {
				// fine
				Fine fine = new Fine();
				fine.setAmount(100d);
				fine.setPaymentDate(new Date());
				fineRepository.save(fine);
			}
			Issue issue = new Issue();
			issue.setId(alreadyIssuedDetails.getId());
			issue.setUserId(issueRequest.getUserId());
			issue.setBookId(issueRequest.getBookId());
			issue.setIssueStartDate(LocalDateTime.now());
			issue.setIssueEndDate(alreadyIssuedDetails.getIssueEndDate().plusDays(7));
			issue.setIssueType(ApplicationConstants.ISSUE_TYPE_RENEW);
			issue.setCreateDate(alreadyIssuedDetails.getCreateDate());
			return issueRepository.save(issue);
		} else {
			throw new ResourceNotFound();
		}

	}
}

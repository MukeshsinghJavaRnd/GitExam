package com.lms.lmsrestservice.controller;

import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.lmsrestservice.exception.InternalServerError;
import com.lms.lmsrestservice.exception.ResourceNotFound;
import com.lms.lmsrestservice.model.Book;
import com.lms.lmsrestservice.request.BookRequest;
import com.lms.lmsrestservice.service.BookService;

@RestController
@RequestMapping("books")
public class BookController {

	@Autowired
	BookService bookService;

	@GetMapping
	public ResponseEntity<List<Book>> list() {
		try {
			List<Book> books = bookService.list();
			if (Objects.nonNull(books) && !books.isEmpty()) {
				return new ResponseEntity<>(books, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
		} catch (Exception e) {
			throw new InternalServerError();
		}
	}

	@GetMapping("/{id}")
	public ResponseEntity<Book> getBookById(@PathVariable Long id) {

		try {
			Book book = bookService.getBook(id);
			return new ResponseEntity<>(book, HttpStatus.OK);
		} catch (Exception e) {
			throw new ResourceNotFound();
		}
	}

	@PostMapping
	public ResponseEntity saveBook(@Valid @RequestBody BookRequest bookRequest) {
		try {
			bookService.save(bookRequest);
			return new ResponseEntity<>("Book has been saved", HttpStatus.CREATED);
		} catch (Exception e) {
			throw new InternalServerError();
		}
	}

	@PutMapping
	public ResponseEntity<Void> updateBook(@Valid @RequestBody BookRequest bookRequest) {
		try {
			bookService.update(bookRequest);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			throw new InternalServerError();
		}
	}

	@DeleteMapping
	public ResponseEntity<Void> deleteBook(@Valid @RequestBody BookRequest bookRequest) {
		try {
			bookService.delete(bookRequest);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			throw new InternalServerError();
		}
	}

}

package com.lms.lmsrestservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomizedExceptionHandling extends ResponseEntityExceptionHandler {

	@ExceptionHandler(ResourceNotFound.class)
	public ResponseEntity<Object> resourceNotFound(ResourceNotFound exception, WebRequest webRequest) {
		ExceptionResponse response = new ExceptionResponse();
		response.setMessage("Requested resource not found");
		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InternalServerError.class)
	public ResponseEntity<Object> internalServerError(InternalServerError exception, WebRequest webRequest) {
		ExceptionResponse response = new ExceptionResponse();
		response.setMessage("Internal server error");
		return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
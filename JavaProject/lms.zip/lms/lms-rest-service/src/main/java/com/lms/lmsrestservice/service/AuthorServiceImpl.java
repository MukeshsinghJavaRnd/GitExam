package com.lms.lmsrestservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.lmsrestservice.model.Author;
import com.lms.lmsrestservice.repository.AuthorRepository;

@Service
public class AuthorServiceImpl implements AuthorService {
	
	@Autowired
	AuthorRepository authorRepository;

	@Override
	public List<Author> list() {		
		return authorRepository.findAll();
	}
	
	

}


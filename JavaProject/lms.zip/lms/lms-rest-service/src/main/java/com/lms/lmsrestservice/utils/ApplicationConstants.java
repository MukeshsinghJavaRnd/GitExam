package com.lms.lmsrestservice.utils;

public class ApplicationConstants {

	public static final Integer ISSUE_TYPE_ISSUE = 1;
	public static final Integer ISSUE_TYPE_RETURN = 2;
	public static final Integer ISSUE_TYPE_RENEW = 3;

}

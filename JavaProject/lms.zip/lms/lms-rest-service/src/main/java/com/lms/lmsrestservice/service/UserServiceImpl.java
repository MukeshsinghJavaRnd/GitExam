package com.lms.lmsrestservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.lmsrestservice.exception.ResourceNotFound;
import com.lms.lmsrestservice.model.User;
import com.lms.lmsrestservice.repository.UserRepository;
import com.lms.lmsrestservice.request.UserRequest;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;

	@Override
	public void save(UserRequest userRequest) {
		User user = new User();
		user.setEmail(userRequest.getEmail());
		user.setName(userRequest.getName());
		userRepository.save(user);
	}

	@Override
	public void update(UserRequest userRequest) {
		User user = new User();
		user.setId(userRequest.getId());
		user.setEmail(userRequest.getEmail());
		user.setName(userRequest.getName());
		userRepository.save(user);
	}

	@Override
	public void delete(UserRequest userRequest) {
		User user = new User();
		user.setId(userRequest.getId());
		user.setEmail(userRequest.getEmail());
		user.setName(userRequest.getName());
		userRepository.delete(user);
	}

	@Override
	public User getUser(Long id) {
		Optional<User> optional = userRepository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		throw new ResourceNotFound();
	}

	@Override
	public List<User> list() {
		return userRepository.findAll();
	}

}

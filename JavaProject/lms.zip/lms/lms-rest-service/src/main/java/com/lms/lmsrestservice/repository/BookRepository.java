package com.lms.lmsrestservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lms.lmsrestservice.model.Book;

public interface BookRepository extends JpaRepository<Book, Long>{

}

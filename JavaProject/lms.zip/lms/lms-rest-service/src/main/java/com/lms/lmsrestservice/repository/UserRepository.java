package com.lms.lmsrestservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lms.lmsrestservice.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

}

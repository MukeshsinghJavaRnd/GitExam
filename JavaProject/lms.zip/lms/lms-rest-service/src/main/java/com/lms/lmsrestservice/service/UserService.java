package com.lms.lmsrestservice.service;

import java.util.List;

import com.lms.lmsrestservice.model.User;
import com.lms.lmsrestservice.request.UserRequest;

public interface UserService {

	public void save(UserRequest userRequest);

	public void update(UserRequest userRequest);

	public void delete(UserRequest userRequest);

	public User getUser(Long id);

	public List<User> list();

}

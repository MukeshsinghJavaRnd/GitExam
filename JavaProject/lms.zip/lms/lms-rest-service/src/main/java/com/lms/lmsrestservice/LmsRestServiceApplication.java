package com.lms.lmsrestservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmsRestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LmsRestServiceApplication.class, args);
	}

}

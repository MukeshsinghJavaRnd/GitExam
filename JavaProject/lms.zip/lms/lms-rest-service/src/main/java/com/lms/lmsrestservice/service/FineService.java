package com.lms.lmsrestservice.service;

public interface FineService {

}

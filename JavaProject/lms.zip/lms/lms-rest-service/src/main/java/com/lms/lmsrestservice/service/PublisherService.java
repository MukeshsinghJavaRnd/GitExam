package com.lms.lmsrestservice.service;

public interface PublisherService {

}

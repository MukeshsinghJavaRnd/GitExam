package com.lms.lmsrestservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lms.lmsrestservice.model.Fine;

public interface FineRepository extends JpaRepository<Fine, Long> {

}

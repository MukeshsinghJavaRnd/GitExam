package com.lms.lmsrestservice.exception;

public class InternalServerError extends RuntimeException {

	private static final long serialVersionUID = 1L;

}

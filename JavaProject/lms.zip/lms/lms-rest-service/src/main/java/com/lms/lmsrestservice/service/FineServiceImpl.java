package com.lms.lmsrestservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.lmsrestservice.repository.FineRepository;

@Service
public class FineServiceImpl implements FineService {

	@Autowired
	FineRepository fineRepository;

	// 1. add fine
	// 2. adjust fine

	// 3. get fine for user

}

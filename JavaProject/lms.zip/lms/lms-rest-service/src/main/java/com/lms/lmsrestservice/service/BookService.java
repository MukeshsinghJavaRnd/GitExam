package com.lms.lmsrestservice.service;

import java.util.List;

import com.lms.lmsrestservice.model.Book;
import com.lms.lmsrestservice.request.BookRequest;

public interface BookService {
	
	public void save(BookRequest bookRequest);
	
	public void update(BookRequest bookRequest);
	
	public void delete(BookRequest book);
	
	public Book getBook(Long id);
	
	public List<Book> list();

}

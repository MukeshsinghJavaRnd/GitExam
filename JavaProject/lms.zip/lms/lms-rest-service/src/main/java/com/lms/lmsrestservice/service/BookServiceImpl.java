package com.lms.lmsrestservice.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.lmsrestservice.exception.ResourceNotFound;
import com.lms.lmsrestservice.model.Book;
import com.lms.lmsrestservice.repository.BookRepository;
import com.lms.lmsrestservice.request.BookRequest;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	BookRepository bookRepository;

	@Override
	@Transactional
	public void save(BookRequest bookRequest) {
		Book book = new Book();
		book.setTitle(bookRequest.getTitle());
		book.setYear(bookRequest.getYear());
		book.setIsbn(bookRequest.getIsbn());
		book.setAvailable(bookRequest.getAvailable());
		bookRepository.save(book);
	}

	@Override
	@Transactional
	public void update(BookRequest bookRequest) {
		Book book = new Book();
		book.setId(bookRequest.getId());
		book.setTitle(bookRequest.getTitle());
		book.setYear(bookRequest.getYear());
		book.setIsbn(bookRequest.getIsbn());
		book.setAvailable(bookRequest.getAvailable());
		bookRepository.save(book);
	}

	@Override
	@Transactional
	public void delete(BookRequest bookRequest) {
		Book book = new Book();
		book.setId(bookRequest.getId());
		book.setTitle(bookRequest.getTitle());
		book.setYear(bookRequest.getYear());
		book.setIsbn(bookRequest.getIsbn());
		bookRepository.delete(book);
	}

	@Override
	public Book getBook(Long id) {
		Optional<Book> optionalBook = bookRepository.findById(id);
		if (optionalBook.isPresent()) {
			return optionalBook.get();
		} else {
			throw new ResourceNotFound();
		}
	}

	@Override
	public List<Book> list() {
		return bookRepository.findAll();
	}

}

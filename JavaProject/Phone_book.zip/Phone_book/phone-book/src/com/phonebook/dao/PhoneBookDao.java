package com.phonebook.dao;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

import com.phonebook.PhoneBookApplication;
import com.phonebook.dto.UserDetails;
import org.json.simple.JSONObject;
import org.json.simple.parser.*;

public class PhoneBookDao {

    Scanner scanner = new Scanner(System.in);
    PhoneBookApplication application = new PhoneBookApplication();
    List<UserDetails> details = new ArrayList<>();
    List<UserDetails> loginUserDetails = new ArrayList<>();
    UserDetails loggedInUser = new UserDetails();

    public UserDetails login() {
        details = application.getDetailsList();

        try {
            Object ob = new JSONParser().parse(new FileReader("D://workspace/login.json"));
            List<UserDetails> userDetails = (List<UserDetails>) ob;

            for (Object o : userDetails) {
                UserDetails ud = new UserDetails();
                ud.setLoginName((String) ((JSONObject) o).get("loginName"));
                ud.setPassword((String) ((JSONObject) o).get("password"));
                ud.setStatus((String) ((JSONObject) o).get("status"));
                ud.setRole((String) ((JSONObject) o).get("role"));

                loginUserDetails.add(ud);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("Enter login credentials");
        System.out.print("Login Id : ");
        String loginName = scanner.next();

        System.out.print("Password : ");
        String password = scanner.next();

        // Check
        UserDetails userDetails = loginUserDetails.stream().filter(u -> (u.getLoginName().equalsIgnoreCase(loginName)) &&
                (u.getPassword().equalsIgnoreCase(password)) && (u.getStatus().equalsIgnoreCase("ACTIVE")))
                .findFirst().orElse(null);

        if (!Objects.nonNull(userDetails)) {
            System.out.print("Invalid Credentials. Do you want to try again? y/n : ");
            String ans = scanner.next();
            loggedInUser = userDetails;
            if (ans.equalsIgnoreCase("y")) {
                login();
            }
        }
        return userDetails;
    }

    public UserDetails getLoggedInUser() {
        return loggedInUser;
    }

}

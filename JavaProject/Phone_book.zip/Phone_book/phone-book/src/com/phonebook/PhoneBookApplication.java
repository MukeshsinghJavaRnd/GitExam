package com.phonebook;

import com.phonebook.dto.UserDetails;
import com.phonebook.service.PhoneBookService;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PhoneBookApplication {

    static List<UserDetails> details = new ArrayList<>();
    static UserDetails loggedInUser = new UserDetails();

    public static void main(String[] args) {
        PhoneBookService application = new PhoneBookService();
        try {
            // Login
            loggedInUser = application.login();
            if (Objects.nonNull(loggedInUser)) {
                System.out.println("Welcome. Login Success !!");
                application.launchMenus();
            } else {
                System.out.println("Bye");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<UserDetails> getDetailsList () {
        return details;
    }

}

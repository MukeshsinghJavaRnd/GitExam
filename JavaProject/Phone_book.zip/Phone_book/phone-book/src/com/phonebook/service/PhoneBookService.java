package com.phonebook.service;

import com.phonebook.dao.PhoneBookDao;
import com.phonebook.dto.UserDetails;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class PhoneBookService {

    static UserDetails loggedInUser = new UserDetails();
    static List<UserDetails> details = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);

    public UserDetails login() {
        PhoneBookDao phoneBookDao = new PhoneBookDao();
        UserDetails userDetails = phoneBookDao.login();
        loggedInUser = userDetails;
        return loggedInUser;
    }

    public void launchMenus() {
        System.out.println("----------------");
        System.out.println("Please select action");
        System.out.println("Enter 1 for Add Users");
        System.out.println("Enter 2 for Edit User");
        System.out.println("Enter 3 for Delete User");
        System.out.println("Enter 4 for User List");
        System.out.println("Enter 5 for View Details");
        System.out.println("Enter 0 for Exit/Logout");

        Integer action = scanner.nextInt();
        switch (action) {
            case 1: {
                insertUserDetails();
                launchMenus();
            }
            break;
            case 2: {
                editUser();
                launchMenus();
            }
            break;
            case 3: {
                deleteList();
                launchMenus();
            }
            break;
            case 4: {
                printList(details);
                launchMenus();
            }
            break;
            case 5: {
                UserDetails userDetails = viewUserDetails();
                if (Objects.nonNull(userDetails))
                    System.out.println(userDetails.toString());

                launchMenus();
            }
            break;
            default: {
                System.out.println("Exit Bye");
            }
            break;
        }
    }

    public List<UserDetails> insertUserDetails() {
        System.out.println("Enter User Details");

        System.out.print("First Name : ");
        String firstName = scanner.next();

        System.out.print("Last Name : ");
        String lastName = scanner.next();

        System.out.print("Email : ");
        String email = scanner.next();

        System.out.print("Mobile : ");
        String mobile = scanner.next();

        System.out.print("LoginName : ");
        String loginName = scanner.next();

        System.out.print("Password : ");
        String password = scanner.next();

        System.out.print("Status : ");
        String status = scanner.next().toUpperCase();

        System.out.print("Role(Admin/User) : ");
        String role = scanner.next().toUpperCase();

        System.out.print("DOB(d/MM/yyyy) : ");
        String dateString = scanner.next().toUpperCase();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate dob = LocalDate.parse(dateString, formatter);

        details.add(new UserDetails(firstName, lastName, email, mobile, loginName, password, status, role, dob));

        System.out.print("Do you want add more record? : y/n - ");
        String addMore = scanner.next();

        if (addMore.equalsIgnoreCase("y"))
            insertUserDetails();

        return details;
    }

    public void editUser() {
        System.out.println("Enter email id for edit");
        UserDetails userDetails = this.viewUserDetails();
        if (Objects.nonNull(userDetails)) {
            System.out.println("Enter new details");

            System.out.print("First Name : ");
            String firstName = scanner.next();

            System.out.print("Last Name : ");
            String lastName = scanner.next();

            System.out.print("Email : ");
            String email = scanner.next();

            System.out.print("Mobile : ");
            String mobile = scanner.next();

            System.out.print("LoginName : ");
            String loginName = scanner.next();

            System.out.print("Password : ");
            String password = scanner.next();

            System.out.print("Status : ");
            String status = scanner.next().toUpperCase();

            System.out.print("Role(Admin/User) : ");
            String role = scanner.next().toUpperCase();

            System.out.print("DOB(d/MM/yyyy) : ");
            String dateString = scanner.next().toUpperCase();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
            LocalDate dob = LocalDate.parse(dateString, formatter);

            userDetails.setFirstName(firstName);
            userDetails.setLoginName(lastName);
            userDetails.setEmail(email);
            userDetails.setMobile(mobile);
            userDetails.setPassword(password);
            userDetails.setStatus(status);
            userDetails.setRole(role);
            userDetails.setDob(dob);

            details.add(userDetails);


        } else {
            System.out.println("User not found");
        }

    }

    public UserDetails viewUserDetails() {
        System.out.println("Enter Email id");
        String email = scanner.next();
        UserDetails userDetails = null;
        if (Objects.nonNull(details) && !details.isEmpty()) {
            userDetails = details.stream().filter(u -> (u.getEmail().equalsIgnoreCase(email))).findFirst().orElse(null);
        } else {
            System.out.println("User List is empty");
        }
        return userDetails;
    }

    public boolean deleteList() {
//        PhoneBookDao phoneBookDao = new PhoneBookDao();
//        loggedInUser = phoneBookDao.getLoggedInUser();
        if (loggedInUser.getRole().equalsIgnoreCase("admin") && loggedInUser.getStatus().equalsIgnoreCase("ACTIVE")) {
            System.out.println("Enter email id for delete");
            UserDetails userDetails = this.viewUserDetails();

            if (Objects.nonNull(details) && !details.isEmpty()) {
                if (Objects.nonNull(userDetails)) {
                    details.remove(userDetails);
                    System.out.println("User deleted");
                    return true;
                } else {
                    System.out.println("User not found");
                }
            }
        } else {
            System.out.println("You dont have access to delete user.");
        }
        return false;
    }

    public void printList(List<UserDetails> userDetails) {
        if (Objects.nonNull(userDetails) && !userDetails.isEmpty()) {
            for (UserDetails details : userDetails) {
                System.out.println(details.toString());
            }
        } else {
            System.out.println("User list is empty");
        }
    }
}

package com.coutrysports.web.model;

import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(uniqueConstraints={@UniqueConstraint(columnNames = "countryName" )})
@Cacheable  
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class Country {
	@Id
	@SequenceGenerator(name = "CountryGenerator", sequenceName = "COUNTRY_SEQUENCE", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "CountryGenerator")
	private Integer countryId;
	
	@OneToOne
	@JoinColumn
	private Language language;
	
	@OneToOne
	@JoinColumn
	private City capital;
	
	private String countryName;
	
	@ManyToMany(mappedBy="country")
	private List<Sport> sport;
	
	
	public List<Sport> getSport() {
		return sport;
	}
	public void setSport(List<Sport> sport) {
		this.sport = sport;
	}	
	public Integer getCountryId() {
		return countryId;
	}
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}
	public Language getLanguage() {
		return language;
	}
	public void setLanguage(Language language) {
		this.language = language;
	}
	public City getCapital() {
		return capital;
	}
	public void setCapital(City capital) {
		this.capital = capital;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	@Override
	public String toString() {
		return "Country [countryId=" + countryId + ", language=" + language + ", capital=" + capital + ", countryName="
				+ countryName + "]";
	}
	
}

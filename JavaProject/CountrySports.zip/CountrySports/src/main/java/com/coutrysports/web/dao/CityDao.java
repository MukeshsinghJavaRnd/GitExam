package com.coutrysports.web.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;

import com.coutrysports.web.model.City;
import com.coutrysports.web.model.Country;
import com.coutrysports.web.model.Sport;
import com.coutrysports.web.util.HibernateUtil;


public class CityDao {
	public static void setCity(City city) {
		try {
//		SessionFactory sessionFactory=HibernateUtil.getCurrentSessionFromConfig();
//		Session session=sessionFactory.openSession();
		Session session=HibernateUtil.getCurrentSessionFromConfig();
		session.beginTransaction();
		session.saveOrUpdate(city);
		session.getTransaction().commit();
		}catch(Exception cse) {
			cse.printStackTrace();
		}
		
//		session.close();
	}
	public static List<City> getCities() {
		Session session=HibernateUtil.getCurrentSessionFromConfig();
		Transaction transaction=session.beginTransaction();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<City> criteria = builder.createQuery(City.class);
		criteria.from(City.class);
		List<City> products = session.createQuery(criteria).getResultList();
		return products;

	}
	public static List<City> getCityFromCityName(String cityName) {
		Session session=HibernateUtil.getCurrentSessionFromConfig();
		session.beginTransaction();
		Query query = session.createQuery("From City c where c.cityName= :cityName");
		query.setParameter("cityName", cityName);
		List<City> cities = query.getResultList();
		
		return cities;
	}
	
	public static City AddCityIfNotExist(String cityName,Country capitalCountry
//			,Sport sport
			) {
		
		List<City> cities = getCityFromCityName(cityName);
		if(cities.isEmpty()) {
			City newCity=new City();
			newCity.setCityName(cityName);
			newCity.setCapitalcountry(capitalCountry);
//			newCity.set
			setCity(newCity);
			cities=getCityFromCityName(cityName);
		}
		
		return cities.get(0);
	}
}

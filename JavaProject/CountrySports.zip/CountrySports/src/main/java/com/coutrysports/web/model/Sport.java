package com.coutrysports.web.model;

import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


@Entity
@Table(uniqueConstraints={@UniqueConstraint(columnNames = "sportName" )})
@Cacheable  
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class Sport {
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	@SequenceGenerator(name = "SportGenerator", sequenceName = "SPORT_SEQUENCE", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "SportGenerator")
private Integer sportId;
private String sportName;
@ManyToMany
private List<Country> country;
public Integer getSportId() {
	return sportId;
}
public List<Country> getCountry() {
	return country;
}
public void setCountry(List<Country> country) {
	this.country = country;
}
public void setSportId(Integer sportId) {
	this.sportId = sportId;
}
public String getSportName() {
	return sportName;
}
public void setSportName(String sportName) {
	this.sportName = sportName;
}
@Override
public String toString() {
	return "Sport [sportId=" + sportId + ", sportName=" + sportName +  "]";
}

}

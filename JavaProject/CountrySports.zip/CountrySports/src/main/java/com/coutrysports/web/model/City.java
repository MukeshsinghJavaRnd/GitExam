package com.coutrysports.web.model;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(uniqueConstraints={@UniqueConstraint(columnNames = "cityName" )})
@Cacheable  
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class City {

@Id
//@GeneratedValue(strategy = GenerationType.AUTO)
@SequenceGenerator(name = "CityGenerator", sequenceName = "CITY_SEQUENCE", allocationSize = 1)
@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "CityGenerator")
private Integer cityId;
	
private String cityName;

@OneToOne
private Country capitalCountry;

public String getCityName() {
	
	return cityName;
}
public void setCityName(String cityName) {
	this.cityName = cityName;
}
public Integer getCityId() {
	return cityId;
}
public void setCityId(Integer cityId) {
	this.cityId = cityId;
}
public Country getCapitalcountry() {
	return capitalCountry;
}
public void setCapitalcountry(Country capitalcountry) {
	this.capitalCountry = capitalcountry;
}
@Override
public String toString() {
	return "City [cityId=" + cityId + ", cityName=" + cityName + "]";
}
}

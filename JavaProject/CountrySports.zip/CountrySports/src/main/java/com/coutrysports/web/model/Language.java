package com.coutrysports.web.model;

import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(uniqueConstraints={@UniqueConstraint(columnNames = "languageName" )})
@Cacheable  
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class Language {
	@Id
	@SequenceGenerator(name = "LanguageGenerator",	 sequenceName = "LANGUAGE_SEQUENCE", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "LanguageGenerator")
private Integer languageId;
private String languageName;

@OneToMany
private List<Country> countries;

public List<Country> getCountries() {
	return countries;
}
public void setCountries(List<Country> countries) {
	this.countries = countries;
}

public Integer getLanguageId() {
	return languageId;
}
public void setLanguageId(Integer languageId) {
	this.languageId = languageId;
}
public String getLanguageName() {
	return languageName;
}
public void setLanguageName(String languageName) {
	this.languageName = languageName;
}
@Override
public String toString() {
	return "Language [languageId=" + languageId + ", languageName=" + languageName + "]";
}


}

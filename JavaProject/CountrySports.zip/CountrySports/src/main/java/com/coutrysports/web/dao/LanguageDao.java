package com.coutrysports.web.dao;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;

import com.countrysports.web.services.LanguageService;
import com.coutrysports.web.model.City;
import com.coutrysports.web.model.Country;
import com.coutrysports.web.model.Language;
import com.coutrysports.web.util.HibernateUtil;

public class LanguageDao {
	public static void setLaguage(Language lang) {
		try {
//		SessionFactory sessionFactory=HibernateUtil.getCurrentSessionFromConfig();
//		Session session=sessionFactory.openSession();
			Session session = HibernateUtil.getCurrentSessionFromConfig();
			Transaction transaction = session.beginTransaction();
			session.saveOrUpdate(lang);
			transaction.commit();
		} catch (Exception cse) {
			cse.printStackTrace();
		}
//		session.close();
	}

	public static List<Language> getLanguages() {
		Session session = HibernateUtil.getCurrentSessionFromConfig();
		Transaction transaction = session.beginTransaction();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Language> criteria = builder.createQuery(Language.class);
		criteria.from(Language.class);
		List<Language> products = session.createQuery(criteria).getResultList();
		return products;

	}

	public static List<Language> getLanguageFromLanguageName(String languageName) {
		Session session = HibernateUtil.getCurrentSessionFromConfig();
		session.beginTransaction();
		Query query = session.createQuery("From Language l where l.languageName= :languageName");
		query.setParameter("languageName", languageName);
		List<Language> countries = query.getResultList();
		return countries;
	}

	public static Language AddLanguageIfNotExist(String languageName, List<Country> Countrylist) {

		List<Language> langugaes = getLanguageFromLanguageName(languageName);
		if (!(langugaes.size() > 0) || 
				!langugaes.get(0).getCountries().containsAll(Countrylist)) {
			Language newLanguage = new Language();
			newLanguage.setLanguageName(languageName);
			if ((langugaes.size() > 0) &&(langugaes.get(0).getCountries().size()>0) && langugaes.get(0).getCountries().containsAll(Countrylist)) {
				newLanguage.setCountries(langugaes.get(0).getCountries());
			} else {
				if ((langugaes.size() > 0) && (langugaes.get(0).getCountries().size()>0))
					Countrylist.addAll(langugaes.get(0).getCountries());
				newLanguage.setCountries(Countrylist);
			}
			setLaguage(newLanguage);
			langugaes = getLanguageFromLanguageName(languageName);

		}
		System.out.println("language is "+languageName);

		return langugaes.get(0);
	}
}

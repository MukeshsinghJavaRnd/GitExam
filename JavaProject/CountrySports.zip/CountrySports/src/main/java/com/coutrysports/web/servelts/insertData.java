package com.coutrysports.web.servelts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.countrysports.web.services.CityService;
import com.countrysports.web.services.CountryService;
import com.countrysports.web.services.LanguageService;
import com.countrysports.web.services.SportService;

/**
 * Servlet implementation class insertData
 */
public class insertData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public insertData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		System.out.println("inserting data");
		
		if( action.equals("insertCountry")) {
			
			String countryName=request.getParameter("countryName");
			String capital=request.getParameter("capital");

			
			
			String language=request.getParameter("Language");
			if(request.getParameter("languagNew")!=null)
				language=request.getParameter("languagNew");

			String[] Sports=request.getParameterValues("Sports");
			String sportcsv=request.getParameter("sportlist");
			List<String> sportsList=new ArrayList<String>();
					
			if(Objects.nonNull(Sports))
			sportsList.addAll(Arrays.asList(Sports));
			if(Objects.nonNull(sportcsv))
			sportsList.addAll(Arrays.asList(sportcsv.split(",")));
			
			
				CountryService.insertCountry(countryName,capital,language,sportsList);
	
				RequestDispatcher rd=request.getRequestDispatcher("Success.jsp");
				rd.forward(request, response);
				
			}
		if( action.equals("insertCity")) {
			
			CityService.insertCities(request, response);

		}
		if( action.equals("insertLanguage")) {
			
			LanguageService.insertLanguages(request, response);

		}
		if( action.equals("insertSport")) {
			
			SportService.insertSports(request, response);

		}
	}


}

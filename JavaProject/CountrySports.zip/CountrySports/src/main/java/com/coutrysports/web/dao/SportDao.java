package com.coutrysports.web.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;

import com.coutrysports.web.model.Country;
import com.coutrysports.web.model.Language;
import com.coutrysports.web.model.Sport;
import com.coutrysports.web.util.HibernateUtil;

public class SportDao {
	public static void setSport(Sport sport) {
		try {
//		SessionFactory sessionFactory=HibernateUtil.getCurrentSessionFromConfig();
//		Session session=sessionFactory.openSession();
		Session session=HibernateUtil.getCurrentSessionFromConfig();
		session.beginTransaction();
		session.saveOrUpdate(sport);
		session.getTransaction().commit();
	}catch(Exception cse) {
		cse.printStackTrace();
	}
//		session.close();
	}
	public static List<Sport> getSports() {
		Session session=HibernateUtil.getCurrentSessionFromConfig();
		Transaction transaction=session.beginTransaction();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Sport> criteria = builder.createQuery(Sport.class);
		criteria.from(Sport.class);
		List<Sport> products = session.createQuery(criteria).getResultList();
		return products;

	}
	public static List<Sport> getSportFromSportName(String sportsName) {
		Session session=HibernateUtil.getCurrentSessionFromConfig();
		session.beginTransaction();
		Query query = session.createQuery("From Sport s where s.sportName like :sportsName");
		query.setParameter("sportsName", sportsName);
		List<Sport> products = query.getResultList();
		return products;
	}
public static Sport AddSportIfNotExist(String sportName,List<Country> Countrylist) {
		
		List<Sport> sports = getSportFromSportName(sportName);
		
		if(!(sports.size()>0) 
				|| ! sports.get(0).getCountry().containsAll(Countrylist)) {
			Sport newSport=new Sport();
			newSport.setSportName(sportName);
			
			if((sports.size()>0)&&(sports.get(0).getCountry().size()>0) &&sports.get(0).getCountry().containsAll(Countrylist))
			{newSport.setCountry(Countrylist);
			}
			else {
				if((sports.size()>0) &&(sports.get(0).getCountry().size()>0))
				Countrylist.addAll(sports.get(0).getCountry());
				newSport.setCountry(Countrylist);	
			}
			setSport(newSport);
			sports=getSportFromSportName(sportName);
		}
		
		return sports.get(0);
	}
}

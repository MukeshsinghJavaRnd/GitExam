package com.coutrysports.web.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;

import com.coutrysports.web.model.City;
import com.coutrysports.web.model.Country;
import com.coutrysports.web.model.Language;
import com.coutrysports.web.model.Sport;
import com.coutrysports.web.util.HibernateUtil;
import java.sql.Statement;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

public class CountryDao {

	public static void setCountry(Country country) {
		try {
		Session session=HibernateUtil.getCurrentSessionFromConfig();
		session.beginTransaction();
		session.saveOrUpdate(country);
		session.getTransaction().commit();
	}catch(Exception cse) {
		cse.printStackTrace();
	}

	}
	public static List<Country> getCountryList() {
			Session session=HibernateUtil.getCurrentSessionFromConfig();
			Transaction transaction=session.beginTransaction();
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<Country> criteria = builder.createQuery(Country.class);
			criteria.from(Country.class);
			List<Country> products = session.createQuery(criteria).getResultList();
			return products;
		
	}
	public static List<Country> getCountryFromCountryName(String countryName) {
		Session session=HibernateUtil.getCurrentSessionFromConfig();
		session.beginTransaction();
		Query query = session.createQuery("From Country c where c.countryName= :countryName");
		query.setParameter("countryName", countryName);
		List<Country> countries = query.getResultList();
		return countries;
	}
public static List<Country> AddCountryIfNotExist(String contryName, City capital,Language language, List<Sport> sportstringList) { 
		
		List<Country> countries = getCountryFromCountryName(contryName);
		
		if(countries.size()<=0 ) {
			Country newCountry=new Country();
			newCountry.setCountryName(contryName);
			newCountry.setCapital(capital);
			newCountry.setLanguage(language);
			newCountry.setSport(sportstringList);
			setCountry(newCountry);
			countries = getCountryFromCountryName(contryName);
		}
		
		
		return countries;
	}
}

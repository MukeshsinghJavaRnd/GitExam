package com.coutrysports.web.servelts;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.countrysports.web.services.CityService;
import com.countrysports.web.services.CountryService;
import com.countrysports.web.services.LanguageService;
import com.countrysports.web.services.SportService;
import com.coutrysports.web.dao.CityDao;
import com.coutrysports.web.dao.LanguageDao;
import com.coutrysports.web.dao.SportDao;

/**
 * Servlet implementation class insertRedirection
 */
public class insertRedirection extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public insertRedirection() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		

		if( action.equals("insertCountry")) {
			request.setAttribute("sportsList",SportDao.getSports());
			request.setAttribute("languageList",LanguageDao.getLanguages());
			request.setAttribute("cityList",CityDao.getCities());
			
			RequestDispatcher rd=request.getRequestDispatcher("insertCountry.jsp");
			rd.forward(request, response);
	
			}
		if( action.equals("insertCity")) {
			
			RequestDispatcher rd=request.getRequestDispatcher("insertCity.jsp");
			rd.forward(request, response);

		}
		if( action.equals("insertLanguage")) {
			
			RequestDispatcher rd=request.getRequestDispatcher("insertLanguage.jsp");
			rd.forward(request, response);

		}
		if( action.equals("insertSport")) {
			
			RequestDispatcher rd=request.getRequestDispatcher("insertSport.jsp");
			rd.forward(request, response);

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

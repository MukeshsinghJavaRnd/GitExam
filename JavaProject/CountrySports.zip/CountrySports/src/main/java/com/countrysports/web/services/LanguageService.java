package com.countrysports.web.services;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.coutrysports.web.dao.CityDao;
import com.coutrysports.web.dao.LanguageDao;
import com.coutrysports.web.model.City;
import com.coutrysports.web.model.Language;

public class LanguageService {
	public static void showLanguages(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				List<Language> languagelist=LanguageDao.getLanguages();
				request.setAttribute("languageList", languagelist);
				RequestDispatcher rd=request.getRequestDispatcher("ShowLangugageList.jsp");
				
					rd.forward(request, response);
				
	}

	public static void insertLanguages(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}
}

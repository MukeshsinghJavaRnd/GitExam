package com.countrysports.web.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.coutrysports.web.dao.CityDao;
import com.coutrysports.web.dao.CountryDao;
import com.coutrysports.web.dao.LanguageDao;
import com.coutrysports.web.dao.SportDao;
import com.coutrysports.web.model.City;
import com.coutrysports.web.model.Country;
import com.coutrysports.web.model.Sport;

public class CountryService {
	public static void showCountries(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				List<Country> coutrylist=CountryDao.getCountryList();
				request.setAttribute("countryList", coutrylist);
				RequestDispatcher rd=request.getRequestDispatcher("ShowCountryList.jsp");
				
					rd.forward(request, response);
				
	}

	public static void insertCountry(String contryName, String capital,String language, List<String> sportstringList) {
		// TODO Auto-generated method stub
		Country country=new Country();
		country.setCountryName(contryName);
		List<Country> countryList=CountryDao.AddCountryIfNotExist(contryName,null,null,null);
		
		country=countryList.get(0);
		
		List<Sport> sportslist=new ArrayList();
		for(String sport:sportstringList)
		{
			sportslist.add(SportDao.AddSportIfNotExist(sport,countryList));
		}
		if(capital!=null&&!capital.equalsIgnoreCase("null"))
		country.setCapital(CityDao.AddCityIfNotExist(capital, country));
		else
			country.setCapital(null);
		System.out.println(countryList.toString());
		if(language!=null&&!language.equalsIgnoreCase("null"))
			country.setLanguage(LanguageDao.AddLanguageIfNotExist(language,countryList));
		else
			country.setLanguage(null);
		
		
		country.setSport(sportslist);
		
		CountryDao.setCountry(country);
		
	}

}

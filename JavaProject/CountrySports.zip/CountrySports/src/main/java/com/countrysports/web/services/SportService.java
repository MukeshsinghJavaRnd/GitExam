package com.countrysports.web.services;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.coutrysports.web.dao.LanguageDao;
import com.coutrysports.web.dao.SportDao;
import com.coutrysports.web.model.Language;
import com.coutrysports.web.model.Sport;

public class SportService {
	public static void showSports(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				List<Sport> sportlist=SportDao.getSports();
				request.setAttribute("sportList", sportlist);
				RequestDispatcher rd=request.getRequestDispatcher("ShowSportList.jsp");
				
					rd.forward(request, response);
				
	}

	public static void insertSports(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}
}

import com.coutrysports.web.dao.CityDao;
import com.coutrysports.web.dao.CountryDao;
import com.coutrysports.web.dao.LanguageDao;
import com.coutrysports.web.dao.SportDao;
import com.coutrysports.web.model.Sport;

public class test {
	public static void main(String args[]) {
		
//		Sport sport=new Sport();
//		sport.setSportName("test5");
//		sport.setCountry(null);
//		SportDao.setSport(sport);
		System.out.println(CityDao.getCities());
	}

}


package com.phbook.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.phbook.Exception.DuplicatePhoneNumberException;
import com.phbook.Exception.PhoneNumberNotExist;
import com.phbook.dao.PhoneBookService;
import com.phbook.dto.PhoneBookDto;

public class PhoneBook
{
	
	public static void main(String[] args) 
	{
		System.out.println("Welcome Phone Book");
		PhoneBookService phoneBookService=new PhoneBookService();
		while(true)
		{
		String regx="[1-6]+";
		String phone="[0-9]+";
		Scanner scanner=new Scanner(System.in);
		System.out.println("Please Select The Option");
		System.out.println("1. To Add A Phone Number "
				+ "2.Find A Phone Number "
				+ "3.Update Phone Book "
				+ "4.Delete Phone Book "
				+ "5.See All the Phone Book "
				+ "6.Quit ");
		
		String inputOption=scanner.nextLine();
		if(inputOption.length()>1)
		{
			System.out.println("Please Select A Valid Option");
		}
		else
		{
		Pattern pattern=Pattern.compile(regx);
		Matcher matcher=pattern.matcher(inputOption);
		if(matcher.matches())
		{
			System.out.println("Your Are Selected Option Is "+inputOption);
			PhoneBookDto phoneBookDto=new PhoneBookDto();
			String phoneNumber=null;
			if((!("5".equalsIgnoreCase(inputOption)))) {
				if(!("6".equalsIgnoreCase(inputOption))){
			System.out.println("Please Enter PhoneNumber");
			 phoneNumber=scanner.nextLine();
			if(phoneNumber==null)
			{
				System.out.println("please Enter a valid Phone Number");
			}
			if(phoneNumber.length()!=10)
			{
				System.out.println("Please Enter Valid Phone Number");
				System.exit(0);
			}
/*			List<String> phoneZero=new ArrayList<String>();
			phoneZero.add("0");
			phoneZero.add("1");
			phoneZero.add("2");
			phoneZero.add("3");
			phoneZero.add("4");
			phoneZero.add("5");
			if(phoneZero.contains(phoneNumber.substring(0,1)))
			{
				System.out.println("Please Enter Valid Phone Number");
				System.exit(0);
			}*/
			Pattern phonepattern=Pattern.compile(phone);
			Matcher Phonematcher=phonepattern.matcher(inputOption);
			if(Phonematcher.matches()==false)
			{
				System.out.println("Phone Number Should Contains Only Numbers");
			}
			
			phoneBookDto.setPhoneNumber(Long.parseLong(phoneNumber));
			}}
			if("1".equalsIgnoreCase(inputOption))
			{
				
				System.out.println("Please Enter Name");
				String name=scanner.nextLine();
				phoneBookDto.setName(name);
				phoneBookDto.setId(name.substring(1,3)+"_"+phoneNumber.substring(1,5));
				try {
					boolean flag=phoneBookService.addPhoneNumber(phoneBookDto);
					if(flag==true)
					System.out.println("You are Added Phone Number SuccessFully"+phoneBookDto.toString());
				} catch (DuplicatePhoneNumberException e)
				{
					e.printStackTrace();
				}
			}
			else if("2".equalsIgnoreCase(inputOption))
			{
				PhoneBookDto phoDto=phoneBookService.getPhoneBook(Long.parseLong(phoneNumber));
				if(phoDto!=null)
					System.out.println("phoneNumber>>>"+phoDto+"<<<<<Found");
			}
			else if("3".equalsIgnoreCase(inputOption))
			{
				System.out.println("Please Enter Name");
				String name=scanner.nextLine();
				PhoneBookDto phoDto=phoneBookService.getPhoneBook(Long.parseLong(phoneNumber));
				phoDto.setName(name);
				boolean flag=false;
				try {
					flag=phoneBookService.updatePhoneNumber(phoneBookDto);
					if(flag)
					System.out.println("PhoneBook Updated SuccessFully");
				} catch (PhoneNumberNotExist e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			else if("4".equalsIgnoreCase(inputOption))
			{
				boolean flag=false;
				try {
					flag=phoneBookService.deletePhoneNumber(Long.parseLong(phoneNumber));
					if(flag)
					System.out.println("Phone Number Delete From Phone Book SuccessFully");
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (PhoneNumberNotExist e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if("5".equalsIgnoreCase(inputOption))
			{
				List<Entry<Long, PhoneBookDto>> phonelist=phoneBookService.getPhoneBook();
				System.out.println(phonelist);
			}
			else
			{
				System.out.println("Thank You");
				System.exit(0);
			}
		}
		else
		{
			System.out.println("You Are Enterd Value Not in the List");
		}
		}
		
	}
	}
}

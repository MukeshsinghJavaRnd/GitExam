package com.phbook.Exception;

public class PhoneNumberNotExist extends Exception
{

	public PhoneNumberNotExist(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}

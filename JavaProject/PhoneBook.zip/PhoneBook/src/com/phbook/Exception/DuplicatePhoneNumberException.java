package com.phbook.Exception;

public class DuplicatePhoneNumberException extends Exception
{

	public DuplicatePhoneNumberException(String arg0) 
	{
		super(arg0);
	}
	
}

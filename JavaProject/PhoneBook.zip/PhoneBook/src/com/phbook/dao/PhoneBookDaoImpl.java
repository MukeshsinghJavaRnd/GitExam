package com.phbook.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import com.phbook.Exception.DuplicatePhoneNumberException;
import com.phbook.Exception.PhoneNumberNotExist;
import com.phbook.dto.PhoneBookDto;

public class PhoneBookDaoImpl implements PhoneBookDao
{
	Map<Long,PhoneBookDto> phonenumbermap=new HashMap<Long, PhoneBookDto>();
	@Override
	public boolean addNumber(PhoneBookDto phoneBookDto) throws DuplicatePhoneNumberException 
	{
		boolean flag =false;
		if(!phonenumbermap.containsKey(phoneBookDto.getPhoneNumber()))
		{
			phonenumbermap.put(phoneBookDto.getPhoneNumber(),phoneBookDto);
			flag=true;
		}
		else
		{
			throw new DuplicatePhoneNumberException("Duplicate PhoneNumber");
		}
		return flag;
	}

	@Override
	public boolean updateNumber(PhoneBookDto phoneBookDto) throws PhoneNumberNotExist 
	{
		boolean flag=false;
		if(phonenumbermap.containsKey(phoneBookDto.getPhoneNumber()))
		{
			phonenumbermap.put(phoneBookDto.getPhoneNumber(),phoneBookDto);
			flag=true;
		}
		else
		{
			throw new PhoneNumberNotExist("Phone Number Not Exist");
		}
		return flag;
	}

	@Override
	public boolean delete(long phoneNo) throws PhoneNumberNotExist 
	{
		boolean flag=false;
		if(phonenumbermap.containsKey(phoneNo))
		{
			phonenumbermap.remove(phoneNo);
			flag=true;
		}
		else
		{
			throw new PhoneNumberNotExist("Phone Number Not Exist");
		}
		return flag;
	}

	@Override
	public List<Entry<Long, PhoneBookDto>> getDetails() 
	{
		List<Entry<Long, PhoneBookDto>> phoList=null;
		if(phonenumbermap.size()>0)
		{
			phoList=phonenumbermap.entrySet().stream().collect(Collectors.toList());
		}
		return phoList;
	}

	@Override
	public PhoneBookDto getPhoneBook(long phoneNo) 
	{
		PhoneBookDto phoneBookDto=new  PhoneBookDto();
		phoneBookDto=phonenumbermap.get(phoneNo);
		return phoneBookDto;
	}
	
	
	
	
}

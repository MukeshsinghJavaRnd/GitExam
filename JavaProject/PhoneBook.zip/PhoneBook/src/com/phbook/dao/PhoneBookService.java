package com.phbook.dao;

import java.util.List;
import java.util.Map.Entry;

import com.phbook.Exception.DuplicatePhoneNumberException;
import com.phbook.Exception.PhoneNumberNotExist;
import com.phbook.dto.PhoneBookDto;

public class PhoneBookService 
{
	PhoneBookDao phoneBookDao=null;
	public List<Entry<Long, PhoneBookDto>> getPhoneBook()
	{
		phoneBookDao=new PhoneBookDaoImpl();
		List<Entry<Long, PhoneBookDto>> phoneBookList=phoneBookDao.getDetails();
		return phoneBookList;
	}
	
	public boolean addPhoneNumber(PhoneBookDto phoneBookDto) throws DuplicatePhoneNumberException
	{
		boolean flag=false;
		phoneBookDao=new PhoneBookDaoImpl();
		flag=phoneBookDao.addNumber(phoneBookDto);
		return flag;
	}
	
	public boolean updatePhoneNumber(PhoneBookDto phoneBookDto) throws PhoneNumberNotExist
	{
		boolean flag=false;
		phoneBookDao=new PhoneBookDaoImpl();
		flag=phoneBookDao.updateNumber(phoneBookDto);
		return flag;
	}
	
	public boolean deletePhoneNumber(long phoneNumber) throws PhoneNumberNotExist
	{
		boolean flag=false;
		phoneBookDao=new PhoneBookDaoImpl();
		flag=phoneBookDao.delete(phoneNumber);
		return flag;
	}
	
	public PhoneBookDto getPhoneBook(long phoneNo)
	{
		PhoneBookDto phoneBookDto=null;
		phoneBookDto=phoneBookDao.getPhoneBook(phoneNo);
		return phoneBookDto;
	}
	
}

package com.phbook.dao;

import java.util.List;
import java.util.Map.Entry;

import com.phbook.Exception.DuplicatePhoneNumberException;
import com.phbook.Exception.PhoneNumberNotExist;
import com.phbook.dto.PhoneBookDto;

public interface PhoneBookDao 
{
	public boolean addNumber(PhoneBookDto phoneBookDto) throws DuplicatePhoneNumberException;
	public boolean updateNumber(PhoneBookDto phoneBookDto) throws PhoneNumberNotExist;
	public boolean delete(long phoneNo) throws PhoneNumberNotExist;
	public List<Entry<Long, PhoneBookDto>> getDetails();
	public PhoneBookDto getPhoneBook(long phoneNo);
}

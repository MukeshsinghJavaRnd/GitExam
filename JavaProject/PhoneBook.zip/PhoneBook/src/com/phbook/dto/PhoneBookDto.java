package com.phbook.dto;

public class PhoneBookDto 
{
	private String id;
	private long phoneNumber;
	private String Name;
	
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	@Override
	public String toString() {
		return "PhoneBookDto [id=" + id + ", phoneNumber=" + phoneNumber + ", Name=" + Name + "]";
	}
	
	
	
	
	
}

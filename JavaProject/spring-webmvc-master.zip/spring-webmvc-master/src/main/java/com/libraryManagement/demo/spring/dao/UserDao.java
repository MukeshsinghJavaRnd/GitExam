package com.libraryManagement.demo.spring.dao;

import java.util.List;

import com.libraryManagement.demo.spring.model.User;

public interface UserDao {
   void save(User user);
   void update (User user);
   void delete (User user);
   User getUser(User user);
   List<User> list();
}

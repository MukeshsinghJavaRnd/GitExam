package com.libraryManagement.demo.spring.service;

import java.util.List;
import com.libraryManagement.demo.spring.model.Users;

public interface UsersService {
	void save (Users users);
	void update (Users users);
	void delete (Users users);
	List<Users> list();

}

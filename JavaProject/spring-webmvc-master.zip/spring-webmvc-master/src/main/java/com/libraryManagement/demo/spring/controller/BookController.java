package com.libraryManagement.demo.spring.controller;

import java.util.Locale;

import javax.validation.Valid;

import com.libraryManagement.demo.spring.model.User;
import com.libraryManagement.demo.spring.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.libraryManagement.demo.spring.model.Book;

import com.libraryManagement.demo.spring.service.BookService;


@Controller
public class BookController {
	
	@Autowired
	private BookService bookService;

	@Autowired
	private UserService userService;
	
	@GetMapping("/books")
	public String bookForm(Locale locale, Model model) {
		model.addAttribute("books", bookService.list());
		return "editBook";

	}
	

	@ModelAttribute("book")
    public Book formBackingObject() {
        return new Book();
    }
	@PostMapping("/addBook")
	public String saveBook(@ModelAttribute("book") @Valid Book book, BindingResult result, Model model) {

		if (result.hasErrors()) {
			model.addAttribute("books", bookService.list());
			return "editBooks";
		}
	
	bookService.save(book);
	return "redirect:/";
}


	@PostMapping("/deleteBook")
	public String deleteBook(@ModelAttribute("book") @Valid Book book, BindingResult result, Model model) {

		if (result.hasErrors()) {
			model.addAttribute("books", bookService.list());
			return "editBooks";
		}

		bookService.delete(book);

		return "redirect:/";
	}

	@PostMapping("/editBook")
	public String editBook(@ModelAttribute("book") @Valid Book book, BindingResult result, Model model) {

		if (result.hasErrors()) {
			model.addAttribute("books", bookService.list());
			return "editBooks";
		}

		bookService.update(book);

		return "redirect:/";
	}

	@PostMapping("/issueBook")
	public String issueBook(@ModelAttribute("book") @Valid Book book, @ModelAttribute("user") @Valid User user,BindingResult result, Model model) {

		if(null != bookService.getBook(book)){

		}

		return "redirect:/";
	}
}

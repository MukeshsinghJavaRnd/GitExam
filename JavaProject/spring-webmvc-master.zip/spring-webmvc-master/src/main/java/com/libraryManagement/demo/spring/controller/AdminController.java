package com.libraryManagement.demo.spring.controller;

public class AdminController {
}

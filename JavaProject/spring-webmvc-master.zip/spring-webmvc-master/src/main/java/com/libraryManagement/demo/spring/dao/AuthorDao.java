package com.libraryManagement.demo.spring.dao;

import java.util.List;

import com.libraryManagement.demo.spring.model.Author;


public interface AuthorDao {
	
	/*void save (Author author);
	void update (Author author);
	void delete (Author author);*/
	List<Author> list();

}

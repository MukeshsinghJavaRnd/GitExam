package com.libraryManagement.demo.spring.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import com.libraryManagement.demo.spring.model.Publisher;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class PublisherDaoImp implements PublisherDao {
	
	@Autowired
	   private SessionFactory sessionFactory;

	/*@Override
	public void save(Publisher publisher) {
		sessionFactory.getCurrentSession().save(publisher);
		
	}

	@Override
	public void update(Publisher publisher) {
		sessionFactory.getCurrentSession().save(publisher);
		
	}

	@Override
	public void delete(Publisher publisher) {
		sessionFactory.getCurrentSession().save(publisher);
		
	}*/

	@Override
	public List<Publisher> list() {
		@SuppressWarnings("unchecked")
		TypedQuery<Publisher> query = sessionFactory.getCurrentSession().createQuery("from PUBLISHER");
	      return  query.getResultList();
	}


}

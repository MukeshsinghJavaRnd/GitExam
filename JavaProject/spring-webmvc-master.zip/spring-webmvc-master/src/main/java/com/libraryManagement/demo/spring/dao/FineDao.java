package com.libraryManagement.demo.spring.dao;

import java.util.List;


import com.libraryManagement.demo.spring.model.Fine;

public interface FineDao {
	
	void save (Fine fine);
	void update (Fine fine);
	void delete (Fine fine);
	List<Fine> list();

}

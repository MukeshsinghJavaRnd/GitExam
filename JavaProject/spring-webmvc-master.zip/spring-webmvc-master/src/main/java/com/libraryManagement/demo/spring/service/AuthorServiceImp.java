package com.libraryManagement.demo.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.libraryManagement.demo.spring.dao.AuthorDao;
import com.libraryManagement.demo.spring.model.Author;
@Service
public class AuthorServiceImp implements AuthorService{
	
	@Autowired
	   private AuthorDao authorDao;
	 
	 /*@Transactional
	   public void save(Author author) {
	      authorDao.save(author);
	      
	 }
	 @Transactional
	public void update (Author author){
	authorDao.update(author);
	}
	 
	 @Transactional
		public void delete (Author author){
		authorDao.delete(author);
}*/
	 
	 @Transactional(readOnly = true)
	   public List<Author> list() {
	      return authorDao.list();
	   }
	
	

}

package com.libraryManagement.demo.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.libraryManagement.demo.spring.dao.PublisherDao;
import com.libraryManagement.demo.spring.model.Publisher;
@Service
public class PublisherServiceImp implements PublisherService {
	
	@Autowired
	private PublisherDao publisherDao;
	
	/*@Transactional
	public void save (Publisher publisher) {
	publisherDao.save(publisher);
	
	}
	@Transactional
	public void update (Publisher publisher) {
	publisherDao.update(publisher);
	
	}
	
	@Transactional
	public void delete (Publisher publisher) {
	publisherDao.delete(publisher);
	
	}*/
	
	@Transactional(readOnly = true)
	   public List<Publisher> list() {
	      return publisherDao.list();
	   }
}

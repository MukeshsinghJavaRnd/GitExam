package com.libraryManagement.demo.spring.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import com.libraryManagement.demo.spring.model.Users;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UsersDaoImp implements UsersDao{
	
	@Autowired
	   private SessionFactory sessionFactory;

	@Override
	public void save(Users users) {
		sessionFactory.getCurrentSession().save(users);
		
	}

	@Override
	public void update(Users users) {
		sessionFactory.getCurrentSession().update(users);
		
	}

	@Override
	public void delete(Users users) {
		sessionFactory.getCurrentSession().delete(users);
		
	}

	@Override
	public List<Users> list() {
		@SuppressWarnings("unchecked")
		TypedQuery<Users> query = sessionFactory.getCurrentSession().createQuery("from USERS");
	      return  query.getResultList();
	
	}

}

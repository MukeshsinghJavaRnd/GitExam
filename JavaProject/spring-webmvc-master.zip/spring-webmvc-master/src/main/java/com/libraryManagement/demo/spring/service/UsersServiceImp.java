package com.libraryManagement.demo.spring.service;

import java.util.List;

import com.libraryManagement.demo.spring.model.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.libraryManagement.demo.spring.dao.UsersDao;

@Service
public class UsersServiceImp implements UsersService {
	
	
	   @Autowired
	   private UsersDao usersDao;
	 
	 @Transactional
	   public void save(Users users) {
	      usersDao.save(users);
	      
	 }
	 @Transactional
	public void update (Users users){
	usersDao.update(users);
	}
	 
	 @Transactional
		public void delete (Users users){
		usersDao.delete(users);
}
	 
	 @Transactional(readOnly = true)
	   public List<Users> list() {
	      return usersDao.list();
	   }
	

}

package com.libraryManagement.demo.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.libraryManagement.demo.spring.dao.BookDao;
import com.libraryManagement.demo.spring.model.Book;

@Service
public class BookServiceImp implements BookService{
	
	 @Autowired
	   private BookDao bookDao;
	 
	 @Transactional
	   public void save(Book book) {
	      bookDao.save(book);
	      
	 }
	 @Transactional
	public void update (Book book){
	bookDao.update(book);
	}
	 
	 @Transactional
		public void delete (Book book){
		bookDao.delete(book);
}

	@Override
	public Book getBook(Book book) {
		return null;
	}

	@Transactional(readOnly = true)
	   public List<Book> list() {
	      return bookDao.list();
	   }
}

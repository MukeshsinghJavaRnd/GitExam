package com.libraryManagement.demo.spring.dao;

import java.util.List;


import com.libraryManagement.demo.spring.model.Publisher;

public interface PublisherDao {
	
	/*void save (Publisher publisher);
	void update (Publisher publisher);
	void delete (Publisher publisher);*/
	List<Publisher> list();

}

package com.libraryManagement.demo.spring.service;

import java.util.List;

import com.libraryManagement.demo.spring.model.Author;

public interface AuthorService {
	
	/*void save (Author author);
	void update (Author author);
	void delete (Author author);*/
	List<Author> list();

}

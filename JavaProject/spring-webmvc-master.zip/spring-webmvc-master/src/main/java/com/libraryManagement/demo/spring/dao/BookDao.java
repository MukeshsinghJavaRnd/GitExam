package com.libraryManagement.demo.spring.dao;

import java.util.List;

import com.libraryManagement.demo.spring.model.Book;

public interface BookDao {

	void save (Book book);
	void update (Book book);
	void delete (Book book);
	Book getBook(Book book);
	List<Book> list();
	
}

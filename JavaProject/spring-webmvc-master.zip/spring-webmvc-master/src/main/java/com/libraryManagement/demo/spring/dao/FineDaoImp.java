package com.libraryManagement.demo.spring.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import com.libraryManagement.demo.spring.model.Fine;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class FineDaoImp implements FineDao{
	
	@Autowired
	   private SessionFactory sessionFactory;

	@Override
	public void save(Fine fine) {
		sessionFactory.getCurrentSession().save(fine);
		
	}

	@Override
	public void update(Fine fine) {
		sessionFactory.getCurrentSession().update(fine);
		
	}

	@Override
	public void delete(Fine fine) {
		sessionFactory.getCurrentSession().delete(fine);
		
	}

	@Override
	public List<Fine> list() {
		@SuppressWarnings("unchecked")
		TypedQuery<Fine> query = sessionFactory.getCurrentSession().createQuery("from FINE");
	      return  query.getResultList();
	
	}

}

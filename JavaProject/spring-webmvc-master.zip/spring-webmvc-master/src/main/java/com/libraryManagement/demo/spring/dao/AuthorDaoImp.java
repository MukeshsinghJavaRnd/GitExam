package com.libraryManagement.demo.spring.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import com.libraryManagement.demo.spring.model.Author;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AuthorDaoImp implements AuthorDao{

	@Autowired
	   private SessionFactory sessionFactory;
	
	/*@Override
	public void save(Author author) {
		sessionFactory.getCurrentSession().save(author);
		
	}

	@Override
	public void update(Author author) {
		sessionFactory.getCurrentSession().update(author);
		
	}

	@Override
	public void delete(Author author) {
		sessionFactory.getCurrentSession().delete(author);
		
	}*/

	@Override
	public List<Author> list() {
		@SuppressWarnings("unchecked")
		TypedQuery<Author> query = sessionFactory.getCurrentSession().createQuery("from AUTHOR");
	      return  query.getResultList();
	}
}

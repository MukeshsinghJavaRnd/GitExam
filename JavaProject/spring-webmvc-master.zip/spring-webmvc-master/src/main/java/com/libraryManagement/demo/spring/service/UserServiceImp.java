package com.libraryManagement.demo.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.libraryManagement.demo.spring.dao.UserDao;
import com.libraryManagement.demo.spring.model.User;

@Service
public class UserServiceImp implements UserService {

   @Autowired
   private UserDao userDao;

   @Transactional
   public void save(User user) {
      userDao.save(user);
   }

   public void update(User user) {
      userDao.update(user);
   }


   public void delete(User user) {
      userDao.delete(user);
   }

   public User getUser(User user) {
     return userDao.getUser(user);
   }



   @Transactional(readOnly = true)
   public List<User> list() {
      return userDao.list();
   }

}

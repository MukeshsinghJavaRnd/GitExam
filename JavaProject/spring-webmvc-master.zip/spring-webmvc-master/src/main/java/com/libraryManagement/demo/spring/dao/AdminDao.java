package com.libraryManagement.demo.spring.dao;

public interface AdminDao{
}

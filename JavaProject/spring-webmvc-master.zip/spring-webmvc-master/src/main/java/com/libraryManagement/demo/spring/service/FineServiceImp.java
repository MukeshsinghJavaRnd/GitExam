package com.libraryManagement.demo.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.libraryManagement.demo.spring.dao.FineDao;
import com.libraryManagement.demo.spring.model.Fine;
@Service
public class FineServiceImp implements FineService{
	
	@Autowired
	private FineDao fineDao;
	
	@Transactional
	
	public void save (Fine fine) {
	fineDao.save(fine);

	}

	public void update (Fine fine) {
	fineDao.update(fine);
	}
	

	public void delete (Fine fine) {
	fineDao.delete(fine);
	}
	
	@Transactional(readOnly = true)
	   public List<Fine> list() {
	      return fineDao.list();
	   }
}


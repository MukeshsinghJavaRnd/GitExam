package com.libraryManagement.demo.spring.service;

import java.util.List;

import com.libraryManagement.demo.spring.model.Fine;

public interface FineService {
	
	void save (Fine fine);
	void update (Fine fine);
	void delete (Fine fine);
	List<Fine> list();

}

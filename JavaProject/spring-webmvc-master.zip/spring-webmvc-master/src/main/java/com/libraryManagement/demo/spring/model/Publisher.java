package com.libraryManagement.demo.spring.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name= "PUBLISHER")
public class Publisher implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7312881149866889702L;

	@Id
	@GeneratedValue
	@Column (name = "PUBLISHER_ID")
	private Long id;
	
	@Column (name ="PUBLISHER_NAME")
	private String name;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}

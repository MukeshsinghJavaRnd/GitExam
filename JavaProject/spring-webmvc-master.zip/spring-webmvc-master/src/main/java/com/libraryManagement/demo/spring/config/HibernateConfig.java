package com.libraryManagement.demo.spring.config;

import com.libraryManagement.demo.spring.model.Author;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.libraryManagement.demo.spring.model.Book;
import com.libraryManagement.demo.spring.model.Fine;
import com.libraryManagement.demo.spring.model.Publisher;
import com.libraryManagement.demo.spring.model.User;
import com.libraryManagement.demo.spring.model.Users;

@Configuration
@EnableTransactionManagement
@ComponentScans(value = { @ComponentScan("com.libraryManagement.demo.spring")})
public class HibernateConfig {

	@Autowired
	private ApplicationContext context;

	@Bean
	public LocalSessionFactoryBean getSessionFactory() {
		LocalSessionFactoryBean factoryBean = new LocalSessionFactoryBean();
		factoryBean.setConfigLocation(context.getResource("classpath:hibernate.cfg.xml"));
		factoryBean.setAnnotatedClasses(User.class,Book.class, Users.class, Author.class,Fine.class,Publisher.class);
		return factoryBean;
	}

	@Bean
	public HibernateTransactionManager getTransactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(getSessionFactory().getObject());
		return transactionManager;
	}

}

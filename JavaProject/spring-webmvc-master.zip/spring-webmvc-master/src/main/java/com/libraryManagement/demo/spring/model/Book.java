package com.libraryManagement.demo.spring.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table (name = "BOOK")
public class Book implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6204616688030982231L;

	@Id
	@GeneratedValue
	@Column( name = "ID")
	private Long id;
	
	@Column (name ="TITLE")
	private String title;
	
	@Column (name ="PUBLISHED_YEAR")
	private Integer year;
	
	@Column (name ="ISBN_Number")
	private Long isbn;
	
	@Column (name = "Available")
	private Integer available;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public Long getIsbn() {
		return isbn;
	}

	public void setIsbn(Long isbn) {
		this.isbn = isbn;
	}

	public Integer getAvailable() {
		return available;
	}

	public void setAvailable(Integer available) {
		this.available = available;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	
	}
	
	



package com.libraryManagement.demo.spring.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "FINE")
public class Fine implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1623534847765334496L;

	@Id
	@GeneratedValue
	@Column( name = "id")
	private Long id;
	
	@Column (name = "PAYMENT_DATE")
	private Date paymentDate;

	@Column (name = "FINE_AMOUNT")
	private Double amount;

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	
}

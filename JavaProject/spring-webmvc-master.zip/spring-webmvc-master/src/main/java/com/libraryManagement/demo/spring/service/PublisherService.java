package com.libraryManagement.demo.spring.service;

import java.util.List;

import com.libraryManagement.demo.spring.model.Publisher;

public interface PublisherService {
	
	/*void save (Publisher publisher);
	void update (Publisher publisher);
	void delete (Publisher publisher);*/
	List<Publisher> list();

}

package com.libraryManagement.demo.spring.dao;

public class AdminDaoImpl implements  AdminDao {
}

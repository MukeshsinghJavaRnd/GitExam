package com.libraryManagement.demo.spring.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import com.libraryManagement.demo.spring.model.Book;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BookDaoImp implements BookDao{

	@Autowired
	   private SessionFactory sessionFactory;

	@Override
	public void save(Book book) {
		sessionFactory.getCurrentSession().save(book);
		
	}

	@Override
	public void update(Book book) {
		sessionFactory.getCurrentSession().update(book);
		
	}

	@Override
	public void delete(Book book) {
		sessionFactory.getCurrentSession().delete(book);
		
	}

	@Override
	public Book getBook(Book book) {
		return (Book) sessionFactory.getCurrentSession().createQuery("from User where id ="+ book.getId());
	}

	@Override
	public List<Book> list() {
		@SuppressWarnings("unchecked")
		TypedQuery<Book> query = sessionFactory.getCurrentSession().createQuery("from BOOK");
	      return  query.getResultList();
	
	}
}

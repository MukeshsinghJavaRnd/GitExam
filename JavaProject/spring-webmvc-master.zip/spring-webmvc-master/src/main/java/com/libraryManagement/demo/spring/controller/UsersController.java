package com.libraryManagement.demo.spring.controller;

import java.util.Locale;

import javax.validation.Valid;

import com.libraryManagement.demo.spring.service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.libraryManagement.demo.spring.model.Users;

@Controller
public class UsersController {

	@Autowired
	private UsersService usersService;
	
	@GetMapping("/users")
	public String usersForm(Locale locale, Model model) {
		model.addAttribute("users", usersService.list());
		return "editUsers";
	}
	
	@ModelAttribute("users")
    public Users formBackingObject() {
        return new Users();
    }

	@PostMapping("/addUsers")
	public String saveUsers(@ModelAttribute("user") @Valid Users users, BindingResult result, Model model) {

		if (result.hasErrors()) {
			model.addAttribute("users", usersService.list());
			return "editUsers";
		}

		usersService.save(users);
		return "redirect:/";
	}
}

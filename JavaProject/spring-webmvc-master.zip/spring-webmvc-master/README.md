# Related tutorials

1. [Spring DispatcherServlet](https://howtodoinjava.com/spring5/webmvc/spring-dispatcherservlet-tutorial/)
2. [Spring 5 MVC + Hibernate 5](https://howtodoinjava.com/spring5/webmvc/spring5-mvc-hibernate5-example/)
3. [Spring CORS](https://howtodoinjava.com/spring5/webmvc/spring-mvc-cors-configuration/)
4. [Spring Security 5](https://howtodoinjava.com/spring5/security5/security-java-config-enablewebsecurity-example/)
4. [Spring Security Login Form](https://howtodoinjava.com/spring5/security5/login-form-example/)

 

package net.codejava.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.codejava.models.Enquiry;
import net.codejava.repository.EnquiryRepository;
import net.codejava.request.NewEnquiryRequest;
import net.codejava.response.EnquiryResponse;

@Service
public class EnquiryServiceImpl implements EnquiryService {

	@Autowired
	EnquiryRepository enquiryRepository;

	@Override
	public Enquiry saveNewEnquiry(NewEnquiryRequest er) {
		Enquiry enquiry = new Enquiry();
		enquiry.setName(er.getName());
		enquiry.setContact(er.getContact());
		enquiry.setCourseId(er.getCourseId());
		enquiry.setCreateDate(new Date());
		enquiry.setEmail(er.getEmail());

		return enquiryRepository.save(enquiry);
	}

	@Override
	public List<Enquiry> getAll() {
		return enquiryRepository.findAll();
	}

	@Override
	public List<Enquiry> getTodaysRecords() {
		return enquiryRepository.getTodaysRecords();
	}

	@Override
	public void deleteEnquiry(Long id) {
		enquiryRepository.deleteById(id);
	}

	@Override
	public List<EnquiryResponse> getMyTodaysRecords(Long userId) {
		List<Object[]> objects = enquiryRepository.getMyTodaysRecords(userId);
		List<EnquiryResponse> enquiryResponses = new ArrayList<>();

		if (Objects.nonNull(objects) && !objects.isEmpty()) {
			for (Object[] object : objects) {
				EnquiryResponse e = new EnquiryResponse();
				e.setId(Long.parseLong(object[0].toString()));
				e.setContact(object[1].toString());
				e.setEmail(object[2].toString());
				e.setName(object[3].toString());
				e.setCname(object[4].toString());
				enquiryResponses.add(e);
			}
		}

		return enquiryResponses;
	}

}

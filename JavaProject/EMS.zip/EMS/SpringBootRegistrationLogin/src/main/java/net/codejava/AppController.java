package net.codejava;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import net.codejava.models.Course;
import net.codejava.models.Enquiry;
import net.codejava.models.User;
import net.codejava.repository.UserRepository;
import net.codejava.request.NewEnquiryRequest;
import net.codejava.response.EnquiryResponse;
import net.codejava.service.CourseService;
import net.codejava.service.EnquiryService;
import net.codejava.service.UserService;

@Controller
public class AppController {

	@Autowired
	private CourseService courseService;

	@Autowired
	private UserService userService;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private EnquiryService enquiryService;

	@GetMapping("")
	public String viewHomePage() {
		return "index";
	}

	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User());
		return "signup_form";
	}

	@PostMapping("/process_register")
	public String processRegister(User user) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		userRepo.save(user);
		return "register_success";
	}

	// User Home page
	@GetMapping("/users")
	public String listUsers(Model model, Principal principal, HttpSession session) {
		String userName = principal.getName();
		User user = userService.getUserByEmail(userName);
		List<EnquiryResponse> enquiries = enquiryService.getMyTodaysRecords(user.getId());
		model.addAttribute("enquiries", enquiries);
		return "users";
	}

	@GetMapping("/users/addCourse")
	public String openAddCoursePage(Model model) {
		model.addAttribute("message", "");
		model.addAttribute("course", new Course());
		return "add_course";
	}

	@PostMapping("/addCourse_process")
	public String addCourseProcess(Model model, CourseRequest course) {
		courseService.saveCourse(course);
		model.addAttribute("course", new Course());
		model.addAttribute("message", "Course Added");
		return "add_course";
	}

	@GetMapping("/users/myCoursesList")
	public String myCoursesList(Model model, Principal principal, HttpSession session) {
		User user = userService.getUserByEmail(principal.getName());
		List<Course> courses = courseService.getMyCourse(user.getId());
		model.addAttribute("courses", courses);
		return "my_courses";
	}

	// -- Enquiry

	// Open enquiry form
	@GetMapping("/open_enquiry_form")
	public String openEnquieyForm(Model model) {
		List<Course> courses = courseService.getAllCourse();
		model.addAttribute("enquiry", new Enquiry());
		model.addAttribute("courses", courses);
		return "enquiryForm";
	}

	// Submit Enquiry
	@PostMapping("/submit_enquiry")
	public String submitEnquiry(Model model, NewEnquiryRequest enquiryRequest) {
		model.addAttribute("enquiry", new Enquiry());
		enquiryService.saveNewEnquiry(enquiryRequest);
		List<Course> courses = courseService.getAllCourse();
		model.addAttribute("courses", courses);
		return "enquiryForm";
	}

	@GetMapping("/delete_enquiry/{id}")
	public String deleteEnquiry(@PathVariable("id") Long id, Model model, Principal principal, HttpSession session) {
		enquiryService.deleteEnquiry(id);
		User user = userService.getUserByEmail(principal.getName());
		List<EnquiryResponse> enquiries = enquiryService.getMyTodaysRecords(user.getId());
		model.addAttribute("enquiries", enquiries);
		return "users";
	}

}

package net.codejava.service;

import java.util.List;

import net.codejava.CourseRequest;
import net.codejava.models.Course;

public interface CourseService {

	Course saveCourse(CourseRequest course);

	List<Course> getAllCourse();

	List<Course> getMyCourse(Long userId);

}

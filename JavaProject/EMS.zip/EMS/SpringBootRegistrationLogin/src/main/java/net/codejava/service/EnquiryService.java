package net.codejava.service;

import java.util.List;

import net.codejava.models.Enquiry;
import net.codejava.request.NewEnquiryRequest;
import net.codejava.response.EnquiryResponse;

public interface EnquiryService {

	Enquiry saveNewEnquiry(NewEnquiryRequest er);

	List<Enquiry> getAll();

	List<Enquiry> getTodaysRecords();
	
	List<EnquiryResponse> getMyTodaysRecords(Long userId);

	void deleteEnquiry(Long id);

}

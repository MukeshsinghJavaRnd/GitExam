package net.codejava.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.codejava.CourseRequest;
import net.codejava.models.Course;
import net.codejava.models.User;
import net.codejava.repository.CourseRepository;
import net.codejava.repository.UserRepository;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	CourseRepository courseRepository;

	@Autowired
	UserRepository userRepository;

	@Override
	public Course saveCourse(CourseRequest course) {
		Course crs = new Course();
		crs.setCname(course.getCname());
		crs.setDuration(course.getDuration());
		crs.setFees(course.getFees());

		Optional<User> optionalUser = userRepository.findById(1l);
		crs.setUser(optionalUser.get());

		return courseRepository.save(crs);
	}

	@Override
	public List<Course> getAllCourse() {
		return courseRepository.findAll();
	}

	@Override
	public List<Course> getMyCourse(Long userId) {
		return courseRepository.findByUserId(userId);
	}

}

package net.codejava.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import net.codejava.models.Enquiry;

public interface EnquiryRepository extends JpaRepository<Enquiry, Long> {

	@Query(value = "select e.id, e.contact, e.email, e.name, c.cname from enquiry e join course c on e.course_id = c.id WHERE DATE(`create_date`) = CURDATE() and course_id in (select id from enq_db.course where user_id = :userId)", nativeQuery = true)
	List<Object[]> getMyTodaysRecords(@Param("userId") Long userId);

	@Query(value = "SELECT * FROM enq_db.enquiry WHERE DATE(`create_date`) = CURDATE()", nativeQuery = true)
	List<Enquiry> getTodaysRecords();

}

package net.codejava.service;

import net.codejava.models.User;

public interface UserService {

	User getUserByEmail(String email);

}
